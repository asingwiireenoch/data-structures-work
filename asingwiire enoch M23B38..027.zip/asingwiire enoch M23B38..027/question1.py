#3
def sort(arr):
    if len(arr) <= 1:
        return arr
    else:
        pivot = arr[0]
        left = []
        right = []
        for i in range(1, len(arr)):
            if arr[i] < pivot:
                left.append(arr[i])
            else:
                right.append(arr[i])
        return sort(left) + [pivot] + sort(right)

unsorted_list = [14,27,8,-42,11,35,-9,56,23]
sorted_list = sort(unsorted_list)
print(sorted_list) 

# The time complexity of quick sort algorithm is O(n*log(n)) in average case and O(n^2) in worst case.




 



