class BrowserStack:
    def __init__(self, pages):
        self.stack = pages
        self.current_page = 0

    def navigation(self, url):
        self.stack.append(url)
        self.current_page = len(self.stack) - 1

    def forward(self):
        if self.current_page < len(self.stack) - 1:
            self.current_page += 1
            return self.stack[self.current_page]
        else:
            return None
    def backward(self):
        if self.current_page < len(self.stack) - 1:
            self.current_page -= 1
            return self.stack[self.current_page]


pages = ["www.google.com", "www.github.com", "www.yahoo.com", "www.ucu.com", "www.microsoft.com", "www.skype.com"]
browser = BrowserStack(pages)
print(browser.stack) 
browser.navigation("www.github.com")
print(browser.stack)  
print(browser.backward())  
print(browser.backward())  
print(browser.forward())  
print(browser.forward()) 
print(browser.forward())  
print(browser.forward())  




